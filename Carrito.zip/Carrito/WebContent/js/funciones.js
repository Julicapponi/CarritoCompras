$(document).ready(function(){
	$("tr #btnDelete").click(function(){
		var idProd=$(this).parent().find("#idp").val();
		eliminar(idProd);
	});
	function eliminar(idProd){
		var url="ProdServlet?action=deleteCarrito";
		$.ajax({
			type:'POST',
			url: url,
			data:"idp="+idProd,
			success: function(data, textStatus, jqXHR){
				alert("Registro eliminado!");
			}
		})
	}

	$("tr #Cantidad").click(function(){
		var idProd =$(this).parent().find("#idprod").val();
		var cantidad=$(this).parent().find("#Cantidad").val();
		var idProd = "/ServletProd?action=actualizarCantidad";
		$.ajax({
			type: 'POST',
			url:url,
			data: "idProd="+idProd+"&Cantidad="+cantidad, 
			success: function(data,textStatus,jqXHR){
				location.href="/ServletProd?action=agregarCarrito"
			}
		});
	});
});