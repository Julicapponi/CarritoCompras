window.onload = function () {
    document.getElementById('boton1').onclick = function () {
        evento();
    }
}

function evento()
{
    window.alert('Bienvenido.');
}