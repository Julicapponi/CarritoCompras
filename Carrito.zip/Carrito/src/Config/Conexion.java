package Config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	Connection conn;
	public Connection Conexion() {
		try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_ventas" + "?serverTimezone=UTC", "root", "40116424");
            System.out.println("Conexi�n realizada a la base de datos con �xito.");
        } catch (ClassNotFoundException | SQLException e) {
        	 System.out.println("Error!, conexi�n fallida a la base de datos.");
        	 e.printStackTrace();
        }

        return conn;
		
	}
}
