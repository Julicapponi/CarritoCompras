package Modelo;

public class Carrito {
	int item;
	int idProd;
	String nameProd;
	String descProd;
	double precioCompra;
	int cantidad;
	double subTotal;
	
	public Carrito() {

	}

	public Carrito(int item, int idProd, String nameProd, String descProd, double precioCompra, int cantidad,
			double subTotal) {
		super();
		this.item = item;
		this.idProd = idProd;
		this.nameProd = nameProd;
		this.descProd = descProd;
		this.precioCompra = precioCompra;
		this.cantidad = cantidad;
		this.subTotal = subTotal;

	}

	public int getItem() {
		return item;
	}

	public void setItem(int item) {
		this.item = item;
	}

	public int getIdProd() {
		return idProd;
	}

	public void setIdProd(int idProd) {
		this.idProd = idProd;
	}

	public String getNameProd() {
		return nameProd;
	}

	public void setNameProd(String nameProd) {
		this.nameProd = nameProd;
	}

	public String getDescProd() {
		return descProd;
	}

	public void setDescProd(String descProd) {
		this.descProd = descProd;
	}

	public double getPrecioCompra() {
		return precioCompra;
	}

	public void setPrecioCompra(double precioCompra) {
		this.precioCompra = precioCompra;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}


}
