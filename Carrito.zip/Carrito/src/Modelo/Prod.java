package Modelo;

public class Prod {
	protected int idProd;
	protected String nameProd;
	protected String descProd;
	protected double precioProd;
	protected int stockProd;
	protected int estadoProd;
	protected String nameImg;
	
	
	public Prod(String nameProd,String descProd, double precioProd, int stockProd, int estadoProd) {
		super();
		this.nameProd = nameProd;
		this.descProd = descProd;
		this.precioProd = precioProd;
		this.stockProd = stockProd;
		this.estadoProd = estadoProd;
	}
	

	public Prod(int idProd, String nameProd, String descProd, double precioProd, int stockProd, int estadoProd) {
		super();
		this.idProd = idProd;
		this.nameProd = nameProd;
		this.descProd = descProd;
		this.precioProd = precioProd;
		this.stockProd = stockProd;
		this.estadoProd = estadoProd;
	}


	public Prod(int idProd, String nameProd,String descProd, double precioProd, int stockProd, int estadoProd, String nameImg) {
		super();
		this.idProd = idProd;
		this.nameProd = nameProd;
		this.descProd = descProd;
		this.precioProd = precioProd;
		this.stockProd = stockProd;
		this.estadoProd = estadoProd;
		this.nameImg = nameImg;
	}
	

	public Prod() {
	
	}

	public int getIdProd() {
		return idProd;
	}

	public void setIdProd(int idProd) {
		this.idProd = idProd;
	}

	public String getNameProd() {
		return nameProd;
	}

	public void setNameProd(String nameProd) {
		this.nameProd = nameProd;
	}

	public String getDescProd() {
		return descProd;
	}

	public void setDescProd(String descProd) {
		this.descProd = descProd;
	}

	public double getPrecioProd() {
		return precioProd;
	}

	public void setPrecioProd(double precioProd) {
		this.precioProd = precioProd;
	}

	public int getStockProd() {
		return stockProd;
	}

	public void setStockProd(int stockProd) {
		this.stockProd = stockProd;
	}

	public int getEstadoProd() {
		return estadoProd;
	}

	public void setEstadoProd(int estadoProd) {
		this.estadoProd = estadoProd;
	}

	public String getNameImg() {
		return nameImg;
	}

	public void setNameImg(String nameImg) {
		this.nameImg = nameImg;
	}


	
	
	

}
