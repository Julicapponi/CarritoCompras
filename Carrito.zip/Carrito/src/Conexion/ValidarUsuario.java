package Conexion;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Modelo.User;
import Modelo.UserDAO;


@WebServlet("/ValidarUsuario")
public class ValidarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    UserDAO udao=new UserDAO();
    User us=new User();
    
    public ValidarUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
	//VALIDAR EL INGRESO DEL CLIENTE
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String accion=request.getParameter("accion");
			if(accion.equalsIgnoreCase("Ingresar")) {
				String usercli=request.getParameter("txtuser");
				String dni=request.getParameter("txtpass");
				us=udao.validarLogin(usercli, dni);
				if(us.getUsercli() !=null) {
						request.setAttribute("usuario", us);   //Lo utilizo dentro del cliente-principal.jsp solo para detallar el usuario en el header
						System.out.println("Usuario Logueado");
						request.getRequestDispatcher("Controlador?menu=principal-cliente").forward(request, response);		
				}else {
					request.getRequestDispatcher("cliente-login.jsp").forward(request, response);
					System.out.println("Usuario o contrase�a incorrecta");		
				}				
			}
			else {
				request.getRequestDispatcher("cliente-login.jsp").forward(request, response);
			}
	}
}
