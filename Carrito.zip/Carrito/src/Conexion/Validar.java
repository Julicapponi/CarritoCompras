package Conexion;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Modelo.Administrador;
import Modelo.AdministradorDAO;


@WebServlet("/Validar")
public class Validar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    AdministradorDAO edao=new AdministradorDAO();
    Administrador em=new Administrador();
    
    public Validar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

//VALIDAR EL INGRESO DEL EMPLEADO o ADMINISTRADOR
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String accion=request.getParameter("accion");
			if(accion.equalsIgnoreCase("Ingresar")) {
				String user=request.getParameter("txtuser");
				String pass=request.getParameter("txtpass");
				em=edao.validar(user, pass);
			if(em.getUser() !=null) {
					request.setAttribute("usuario", em);
					System.out.println("Usuario Logueado");
					request.getRequestDispatcher("Controlador?menu=principal").forward(request, response);		
			}else {
				request.getRequestDispatcher("index.jsp").forward(request, response);
				System.out.println("Usuario o contrase�a incorrecta");
				
			}
				
			}
			else {
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
	}

}
