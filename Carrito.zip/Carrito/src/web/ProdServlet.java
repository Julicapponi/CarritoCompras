package web;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Modelo.ProdDAO;
import Modelo.Carrito;
import Modelo.Prod;



@WebServlet("/ServletProd")
@MultipartConfig
public class ProdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private ProdDAO prodDAO;
    int item;
    
    public void init() {
        prodDAO = new ProdDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        String action = request.getParameter("action"); 
        try {
            switch (action) {
                case "newProd":
                    showNewFormProd(request, response);
                    break;
                case "insertProd":
                    insertProd(request, response);
                    break;
                case "deleteProd":
                    deleteProd(request, response);
                    break;
                case "editProd":
                    showEditFormProd(request, response);
                    break;
                case "updateProd":
                    updateProd(request, response);
                    break;
                case "catalogoProd":
                    catalogoProd(request, response);
                    break;
                case "agregarCarrito":
                	agregarCarrito(request, response);
                    break;
                case "actualizarCantidad":
                	actualizarCantidad(request, response);
                    break; 
                case "deleteCarrito":
                	deleteCarrito(request, response);
                    break;
                case "realizarPago":
                	realizarPago(request, response);
                    break;
                case "finalizarPago":
                	finalizarPago(request, response);
                    break;
                default:
                    listProd(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
  
    		//OPERACIONES CON EL PRODUCTO
    
//LISTA DE LOS PRODUCTOS
private void listProd(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException, ServletException {
        List < Prod > listProd = prodDAO.selectAllProds();
        request.setAttribute("listProd", listProd);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/producto-lista.jsp");
        dispatcher.forward(request, response);
}

private void showNewFormProd(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/producto-agregar.jsp");
        dispatcher.forward(request, response);
    }


private void showEditFormProd(HttpServletRequest request, HttpServletResponse response)throws SQLException, ServletException, IOException {
        int idProd = Integer.parseInt(request.getParameter("idProd"));
        Prod existingProd = prodDAO.selectProd(idProd);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/producto-editar.jsp");
        request.setAttribute("prod", existingProd);
        dispatcher.forward(request, response);
    }

// AGREGAR PRODUCTO AL CARRITO
private void agregarCarrito(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException, ServletException {
	List <Carrito> listaCarrito = new ArrayList<>();
	HttpSession ses=request.getSession();		
	if(ses.getAttribute("listaCarrito") != null) {
		listaCarrito =  (List <Carrito>) ses.getAttribute("listaCarrito");	
	}else {
		ses.setAttribute("listaCarrito", listaCarrito);	
	}
	int idProd = Integer.parseInt(request.getParameter("idProd"));
	Prod p = prodDAO.selectProd(idProd);		//selecciono por id y lo guardo en el objeto p
	item=item+1;
	int cantidad=1;
	double totalPagar=0.0;	
	Carrito car = new Carrito();
	car.setItem(item);
	car.setIdProd(p.getIdProd());
	car.setNameProd(p.getNameProd());
	car.setDescProd(p.getDescProd());
	car.setPrecioCompra(p.getPrecioProd());
	car.setCantidad(cantidad);
	car.setSubTotal(cantidad*p.getPrecioProd());
	listaCarrito.add(car);					//agrego todo a la lista carrito
	for(int i=0; i < listaCarrito.size(); i++) {
		   totalPagar=totalPagar + listaCarrito.get(i).getSubTotal(); //sumatoria de la columna subtotal 
	}
	//enviamos datos a jsp
	 request.setAttribute("totalPagar", totalPagar);
	 RequestDispatcher dispatcher = request.getRequestDispatcher("/carrito.jsp"); //solo dejo /carrito.jsp para verificar si lo agrega, pero el cliente tiene que seguir elijiendo
     dispatcher.forward(request, response);
}

//ACTUALIZAR LA CANTIDAD DE ALGUN ITEM DEL CARRITO
private void actualizarCantidad(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException, ServletException {
	List <Carrito> listaCarrito = new ArrayList<>();
	int idProd = Integer.parseInt(request.getParameter("idProd"));
	int cant = Integer.parseInt(request.getParameter("Cantidad"));
	for(int i=0;i<listaCarrito.size();i++) {
		if(listaCarrito.get(i).getIdProd() == idProd) {
			listaCarrito.get(i).setCantidad(cant);
			double st=listaCarrito.get(i).getPrecioCompra() * cant;
			listaCarrito.get(i).setSubTotal(st);
		}
	}
}


//BORRAR PRODUCTO DEL CARRITO
private void deleteCarrito(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException, ServletException {
	List <Carrito> listaCarrito = new ArrayList<>();
	HttpSession ses=request.getSession();		
	if(ses.getAttribute("listaCarrito") != null) {
		listaCarrito =  (List <Carrito>) ses.getAttribute("listaCarrito");	
	}else {
		ses.setAttribute("listaCarrito", listaCarrito);	
	}
	int idProd = Integer.parseInt(request.getParameter("idProd"));
	for(int i=0;i<listaCarrito.size();i++) {
		if(listaCarrito.get(i).getIdProd() == idProd) {
			listaCarrito.remove(i);
			break;
		}
	}
}


private void catalogoProd(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException, ServletException {
	 List < Prod > listProd = prodDAO.selectAllProds();
     request.setAttribute("listProd", listProd);
     RequestDispatcher dispatcher = request.getRequestDispatcher("/catalogo-productos.jsp");
     dispatcher.forward(request, response);
}

// AGREGAR PRODUCTO DE LA LISTA
private void insertProd(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException {
        String nameProd = request.getParameter("nameProd");
        String descProd = request.getParameter("descProd");
        double precioProd = Double.parseDouble(request.getParameter("precioProd").replace(',', '.'));
        int stockProd = Integer.parseInt(request.getParameter("stockProd"));
        int estadoProd = Integer.parseInt(request.getParameter("estadoProd"));
        Prod newProd = new Prod(nameProd, descProd, precioProd, stockProd, estadoProd);
        prodDAO.insertProd(newProd);
        response.sendRedirect("ServletProd?action=listProd");
    }

//EDITAR PRODUCTO DE LA LISTA
private void updateProd(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException {
        int idProd = Integer.parseInt(request.getParameter("idProd"));
        String nameProd = request.getParameter("nameProd");
        String descProd = request.getParameter("descProd");
        double precioProd = Double.parseDouble(request.getParameter("precioProd").replace(',', '.'));
        int stockProd = Integer.parseInt(request.getParameter("stockProd"));
        int estadoProd = Integer.parseInt(request.getParameter("estadoProd"));
        String nameImg = request.getParameter("nameImg");
        Prod book = new Prod(idProd, nameProd, descProd, precioProd, stockProd, estadoProd, nameImg);
        prodDAO.updateProd(book);
        response.sendRedirect("ServletProd?action=listProd");
    }


//BORRAR PRODUCTO DE LA LISTA
private void deleteProd(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException {
        int idProd = Integer.parseInt(request.getParameter("idProd"));
        prodDAO.deleteProd(idProd);
        response.sendRedirect("ServletProd?action=listProd");
    }

private void realizarPago(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
    RequestDispatcher dispatcher = request.getRequestDispatcher("/finalizar-compra.jsp");
    dispatcher.forward(request, response);
}
private void finalizarPago(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
HttpSession ses=request.getSession();
ses.invalidate();
RequestDispatcher dispatcher = request.getRequestDispatcher("/catalogo-productos.jsp");
dispatcher.forward(request, response);
}
}
