package web;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import Modelo.UserDAO;
import Modelo.User;


@WebServlet("/ServletUser")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	UserDAO udao = new UserDAO();
	User us = new User();
	 private UserDAO userDAO;
    public void init() {
        userDAO = new UserDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            switch (action) {
                case "new":
                    showNewForm(request, response);
                    break;
                case "insert":
                    insertUser(request, response);
                    break;
                case "delete":
                    deleteUser(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "update":
                    updateUser(request, response);
                    break;
                case "newRegistro":
                    showNewFormRegistro(request, response);
                    break;
                case "registro":
                    registro(request, response);
                    break;
                case "editUser":
                    showEditFormUser(request, response);
                    break;
                case "cerrarSession":
                    cerrarSession(request, response);
                    break;
                default:
                    listUser(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
    		//OPERACIONES CON EL CLIENTE
private void listUser(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException, ServletException {
        List < User > listUser = userDAO.selectAllUsers();
        request.setAttribute("listUser", listUser);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/cliente-lista.jsp"); //m�todo que se aplica a un objeto de tipo RequestDispatcher
        dispatcher.forward(request, response); //forward reedirige la peticion
    }

private void showNewForm(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/cliente-agregar.jsp");
        dispatcher.forward(request, response); //forward reedirige la peticion
    }
private void showNewFormRegistro(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
    RequestDispatcher dispatcher = request.getRequestDispatcher("/registrar.jsp");
    dispatcher.forward(request, response); //forward reedirige la peticion
}

private void showEditForm(HttpServletRequest request, HttpServletResponse response)throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        User existingUser = userDAO.selectUser(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/cliente-editar.jsp");
        request.setAttribute("user", existingUser);
        dispatcher.forward(request, response); //forward reedirige la peticion
    }


private void insertUser(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException {
		//Se recogen los valores del jsp 
		//"parameter" s�lo puede guardar valores de tipo "String"
		//getParameter devolver� el valor de un par�metro enviado por un formulario "JSP" en este caos
        String name = request.getParameter("name");
        String usercli = request.getParameter("usercli");
        String dni = request.getParameter("dni");
        String email = request.getParameter("email");
        String country = request.getParameter("country");
        User newUser = new User(name,usercli, dni, email, country);
        userDAO.insertUser(newUser);
       // response.sendRedirect("list"); 
        response.sendRedirect("ServletUser?action=listUser");
    }

private void registro(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException {
	        String name = request.getParameter("name");
	        String usercli = request.getParameter("usercli");
	        String dni = request.getParameter("dni");
	        String email = request.getParameter("email");
	        String country = request.getParameter("country");
	        User newUser = new User( name, usercli, dni, email, country);
	        userDAO.insertUser(newUser);
	        response.sendRedirect("cliente-login.jsp");
	    }

private void updateUser(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String usercli = request.getParameter("usercli");
        String dni = request.getParameter("dni");
        String email = request.getParameter("email");
        String country = request.getParameter("country");
        User book = new User(id, name, usercli, dni, email, country);
        userDAO.updateUser(book);
        response.sendRedirect("ServletUser?action=listUser");
    }

private void deleteUser(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        userDAO.deleteUser(id);
        response.sendRedirect("ServletUser?action=listUser");
        
    }
private void showEditFormUser(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
	int id = Integer.parseInt(request.getParameter("id"));
    User existingUser = userDAO.selectUser(id);
    RequestDispatcher dispatcher = request.getRequestDispatcher("/cambiar-datos.jsp");
    request.setAttribute("user", existingUser);
    dispatcher.forward(request, response); //forward reedirige la peticion
}
private void cerrarSession (HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
HttpSession ses=request.getSession();
ses.invalidate();
response.sendRedirect("cliente-login.jsp");
}
}
